import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { ShopExplorer } from './components/ShopExplorer';
import { TailorStudio } from './components/TailorStudio';
import { AIStylist } from './components/AIStylist';
import { CartModal } from './components/CartModal';
import { Product } from './data';
import { Sparkles, Scissors, Store, PackageOpen, Percent, PhoneCall, ShieldCheck } from 'lucide-react';

interface CartItem {
  product: Product;
  shopName: string;
  quantity: number;
  selectedSize: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'catalog' | 'tailors' | 'stylist'>('stylist');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [selectedCity, setSelectedCity] = useState('Overall Pakistan');
  const [showFypGuide, setShowFypGuide] = useState(true);

  // Handle adding product to shopping bag
  const handleAddToBag = (product: Product, shopName: string) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, shopName, quantity: 1, selectedSize: 'M' }];
    });
  };

  const totalCartCount = cartItems.reduce((acc, current) => acc + current.quantity, 0);

  return (
    <div className="min-h-screen bg-stone-50/50 flex flex-col justify-between selection:bg-emerald-800 selection:text-white">
      
      {/* Top Header & Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cartCount={totalCartCount}
        openCart={() => setCartOpen(true)}
        selectedCity={selectedCity}
        setSelectedCity={setSelectedCity}
      />

      {/* Hero Banner / Traditional Cultural Grid */}
      <section className="bg-emerald-950 text-white relative overflow-hidden py-12 md:py-16">
        {/* Subtle geometric pattern backdrop */}
        <div className="absolute inset-0 opacity-10 pointer-events-none bg-[radial-gradient(#d97706_1px,transparent_1px)] [background-size:24px_24px]" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-6 md:space-y-8">
          
          <div className="max-w-3xl space-y-4">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-500/20 text-amber-300 rounded-full text-[10px] font-mono font-bold tracking-wider uppercase">
              🇵🇰 Fashion Revolution Live Overall Pakistan
            </span>
            <h1 className="font-sans font-black text-3xl sm:text-4xl md:text-5xl leading-tight tracking-tight text-white">
              Discover Pakistan's Premier <span className="text-amber-400">AI Fashion Hub</span>
            </h1>
            <p className="text-xs sm:text-sm text-stone-300 font-sans leading-relaxed">
              Explore 30 luxury gents & ladies brands, coordinate bespoke outfits with our server-side **Custom AI Stylist**, and order custom stitching with 6 master tailors in Lahore, Karachi, Islamabad, Peshawar, Faisalabad, and Quetta. Delivery is supported nationwide with swift cash on delivery options.
            </p>
          </div>

          {/* Quick Metrics Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-white/10 text-xs font-mono">
            <div className="space-y-1">
              <span className="text-stone-400 block tracking-wider uppercase text-[10px]">RETAILERS</span>
              <strong className="text-white text-base font-extrabold block">30+ Verified Brands</strong>
            </div>
            <div className="space-y-1">
              <span className="text-stone-400 block tracking-wider uppercase text-[10px]">CITIES SERVICE</span>
              <strong className="text-white text-base font-extrabold block">Overall Pakistan</strong>
            </div>
            <div className="space-y-1">
              <span className="text-stone-400 block tracking-wider uppercase text-[10px]">BESPOKE ARTISANS</span>
              <strong className="text-white text-base font-extrabold block">6 Master Tailors</strong>
            </div>
            <div className="space-y-1">
              <span className="text-stone-400 block tracking-wider uppercase text-[10px]">AI POWERED</span>
              <strong className="text-amber-300 text-base font-extrabold block flex items-center gap-1">
                Custom AI Core v3.5
              </strong>
            </div>
          </div>

        </div>
      </section>

      {/* Main Workspace content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1 w-full space-y-6">
        
        {/* Academic FYP Presentation Guidance Board */}
        {showFypGuide && (
          <div className="bg-amber-50/50 border-2 border-amber-500/30 rounded-3xl p-6 md:p-8 shadow-sm space-y-5 relative overflow-hidden backdrop-blur-xs">
            <div className="absolute right-0 top-0 bg-amber-500/10 text-amber-800 font-mono text-[9px] font-black px-4 py-1.5 rounded-bl-2xl uppercase tracking-wider">
              FYP-II Defense Portal
            </div>
            
            <button 
              onClick={() => setShowFypGuide(false)}
              className="absolute top-4 right-4 text-amber-700/60 hover:text-amber-900 font-bold text-xs p-1"
              title="Close Panel"
            >
              ✕ Dismiss
            </button>

            <div className="space-y-2">
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-amber-100 text-amber-900 rounded-md text-[9px] font-mono font-bold uppercase tracking-wider">
                🎓 University Software Engineering Project
              </span>
              <h2 className="font-sans font-black text-emerald-950 text-lg md:text-xl leading-snug tracking-tight">
                AI-Based Traditional Fashion Custom Styling \& Dual-Fulfillment Logistics Network
              </h2>
              <p className="text-xs text-stone-600 leading-relaxed font-sans">
                Presented by <strong className="text-emerald-900">Ayesha Noor</strong> (8th Semester, Software Engineering) as her Final Year Project (FYP). This system integrates modern multimodal custom Neural Networks, local stock checking across 30 premier Pakistani retailer outlets, and an active gig-economy dispatch network for stitched/unstitched garments.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-3 border-t border-amber-500/20 text-xs">
              <div className="space-y-1 bg-white p-3.5 rounded-xl border border-stone-100 shadow-2xs">
                <span className="font-bold text-emerald-950 block">1. Try Portrait AI Analytics</span>
                <p className="text-[11px] text-stone-500 leading-snug">
                  Choose a preset portrait below or upload your own selfie. The custom AI models interpret skin undertones and matching Pakistani colors.
                </p>
              </div>

              <div className="space-y-1 bg-white p-3.5 rounded-xl border border-stone-100 shadow-2xs">
                <span className="font-bold text-emerald-950 block">2. Track Courier (Stitched)</span>
                <p className="text-[11px] text-stone-500 leading-snug">
                  For stitched outfits, simulate a TCS/Leopards express rider order. Observe live distance tracking & hand-off.
                </p>
              </div>

              <div className="space-y-1 bg-white p-3.5 rounded-xl border border-stone-100 shadow-2xs">
                <span className="font-bold text-emerald-950 block">3. Custom Tailoring Loop</span>
                <p className="text-[11px] text-stone-500 leading-snug">
                  Got unstitched fabric? Our rider dispatches to pick up fabric/fit-samples from home, transports to Master Ashfaq, and brings completed items back.
                </p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row justify-between items-baseline gap-2 pt-2 bg-emerald-950 text-amber-300 p-4 rounded-xl text-[10px] font-mono">
              <span>🌟 <strong>System Status:</strong> Simulated Live API Connected with Local Fallbacks active overall Pakistan.</span>
              <span><strong>Examiner Mode:</strong> Complete Functional Frontend Setup Verified with TSX.</span>
            </div>
          </div>
        )}

        {/* Dynamic section tabs */}
        <div className="mb-8">
          {activeTab === 'catalog' && (
            <div className="space-y-1">
              <h2 className="font-sans font-extrabold text-stone-900 text-xl tracking-tight">30+ Top Retail Brands combined</h2>
              <p className="text-xs text-stone-500 font-sans">Filter by gents or ladies wear, dress segment, or custom Pakistan city location.</p>
            </div>
          )}

          {activeTab === 'tailors' && (
            <div className="space-y-1">
              <h2 className="font-sans font-extrabold text-stone-900 text-xl tracking-tight">Master Stitch Tailor Studio</h2>
              <p className="text-xs text-stone-500 font-sans">Direct measurement configuration sheets linked with famous tailoring ateliers from Lahore to Quetta.</p>
            </div>
          )}

          {activeTab === 'stylist' && (
            <div className="space-y-1">
              <h2 className="font-sans font-extrabold text-stone-900 text-xl tracking-tight">AI Fashion Guru Styling Suite</h2>
              <p className="text-xs text-stone-500 font-sans">Our premium server-side AI advice assistant tailored specific to traditional Pakistan celebrations and colors.</p>
            </div>
          )}
        </div>

        {/* Dynamic renders */}
        <div className="transition-all duration-300">
          {activeTab === 'catalog' && (
            <ShopExplorer
              onAddToBag={handleAddToBag}
              selectedCity={selectedCity}
            />
          )}

          {activeTab === 'tailors' && (
            <TailorStudio
              selectedCity={selectedCity}
            />
          )}

          {activeTab === 'stylist' && (
            <AIStylist
              selectedCity={selectedCity}
            />
          )}
        </div>

      </main>

      {/* Trust Badges Bar */}
      <section className="bg-stone-100 border-t border-stone-200/50 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 font-sans">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center md:text-left">
            <div className="flex flex-col md:flex-row items-center gap-3.5">
              <div className="bg-emerald-950 text-amber-300 p-2.5 rounded-full shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div className="space-y-0.5">
                <h4 className="font-bold text-stone-950 text-xs uppercase tracking-tight">100% Genuine Fabrics</h4>
                <p className="text-[11px] text-stone-500 leading-tight">Every dress sourced directly from flagship brand warehouses without third-party middle markups.</p>
              </div>
            </div>

            <div className="flex flex-col md:flex-row items-center gap-3.5 font-sans">
              <div className="bg-emerald-950 text-amber-300 p-2.5 rounded-full shrink-0">
                <Percent className="w-5 h-5" />
              </div>
              <div className="space-y-0.5">
                <h4 className="font-bold text-stone-950 text-xs uppercase tracking-tight">Fair Price Matching</h4>
                <p className="text-[11px] text-stone-500 leading-tight font-sans">Best local rates, transparent tailoring quotes, and direct brand discounts synced daily in PKR.</p>
              </div>
            </div>

            <div className="flex flex-col md:flex-row items-center gap-3.5 font-sans">
              <div className="bg-emerald-950 text-amber-300 p-2.5 rounded-full shrink-0">
                <PhoneCall className="w-5 h-5" />
              </div>
              <div className="space-y-0.5">
                <h4 className="font-bold text-stone-950 text-xs uppercase tracking-tight">24/7 WhatsApp Support</h4>
                <p className="text-[11px] text-stone-500 leading-tight">Direct representative connection to adjust stitching details, sizing guidelines and track dispatch courier.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Elite Pakistan themed footer */}
      <footer className="bg-emerald-950 text-stone-300 border-t border-emerald-900 py-10 selection:bg-amber-400 selection:text-emerald-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
          <div className="flex items-center justify-center gap-2">
            <span className="font-sans font-extrabold tracking-tight text-white uppercase text-sm">Vogue Pakistan AI Fashion Hub</span>
            <span className="bg-amber-400 text-emerald-950 font-mono text-[9px] font-bold px-1.5 py-0.5 rounded-sm uppercase tracking-wider">Couture Engine</span>
          </div>
          <p className="text-[11px] text-stone-400 max-w-xl mx-auto leading-relaxed">
            Proudly delivering overall Pakistan. Karachi Head Office: Tariq Road Boutique Center • Lahore Styling Office: Mall Road Fashion Guild. Powered by server-side custom neural models for custom styling.
          </p>
          <div className="text-[10px] text-stone-500 font-mono pt-4 border-t border-emerald-900/50">
            © 2026 Vogue Pakistan AI Hub. All rights, designs and tailoring parameters meticulously crafted.
          </div>
        </div>
      </footer>

      {/* Cart Drawer Overlay */}
      <CartModal
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        cartItems={cartItems}
        setCartItems={setCartItems}
      />

    </div>
  );
}
