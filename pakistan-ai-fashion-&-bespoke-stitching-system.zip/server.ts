import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini SDK with custom user agent and correct API key
let ai: GoogleGenAI | null = null;
const apiKey = process.env.GEMINI_API_KEY;

if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
  try {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log("Gemini AI client successfully initialized on backend server.");
  } catch (error) {
    console.error("Error initializing Gemini AI:", error);
  }
} else {
  console.log("Warning: GEMINI_API_KEY environment variable is not defined or is placeholder. Falling back to structured default replies.");
}

// API endpoint for AI Styling Advice with Multimodal Photo Support
app.post("/api/stylist", async (req, res) => {
  const { occasion, gender, stylePreference, bodyType, budgetRange, query, image, skinTone, ageGroup } = req.body;

  let contents: any[] = [];
  
  const prompt = `
Occasion or Event: ${occasion || "Casual / General Celebration"}
Target Fit Gender: ${gender || "Any"}
Style Category: ${stylePreference || "Modern/Traditional Fusion"}
Body / Fit Preference: ${bodyType || "Standard fit"}
Budget Level (PKR): ${budgetRange || "Flexible"}
User's Skin Tone Selection: ${skinTone || "Warm wheatish / average South Asian"}
User's Age Vibe: ${ageGroup || "Young adult (20-30)"}
User's query/special request: "${query || "Suggest typical Pakistani dresses that fit best for this occasion!"}"

Provide highly detailed and structured styling advice for this user. 
Please include the following 4 distinct sections in your markdown output, matching the user's FYP workflow perfectly:
1. ### 🎨 Skin Tone & Aesthetic Analysis
Analyze the user's skin undertone (e.g., warm wheatish, deep caramel, cool ivory, golden peach) and suggest which traditional colors (like emerald green, royal cobalt blue, maroon, pastel pistachio, mustard yellow, ivory cream) will make their personality radiate at the event. Estimate styling directions based on age and event vibe.

2. ### 🛍️ Wardrobe Recommendations (30 Pakistani Shops Matching)
Name 2-3 specific real Pakistani retail brands (such as Khaadi, Sapphire, Junaid Jamshed, Maria B, HSY, Bareeze, Amir Adnan, Limelight, Generation, Alkaram, Gul Ahmed Ideas, Edenrobe, Nishat Linen, Outfitters) that have this specific outfit in stock right now. State whether they should buy it Stitched (Ready-to-Wear) or Unstitched (Fabric suit). Specify expected local price estimates in PKR.

3. ### 🛵 Stitched: Instant Home Delivery Route
If they prefer Stitched / Ready-to-Wear: Explain that our local logistics system will automatically assign a nearby Delivery Rider (such as Leopards Courier or TCS Express) with their live GPS distance. Give them a quick tip on scheduling immediate home handoff within 1-2 hours of the brand purchase.

4. ### 🪡 Unstitched: Tailor Studio and Pick & Drop Logistics
If they prefer Unstitched fabric: Introduce our integrated Tailoring network of 6 Master Tailors (like Master Ashfaq from Lahore, Master Siddique from Karachi). Explain the exact pipeline: A delivery boy will be dispatched to their house to collect the unstitched fabric and their physical size template Kameez, transport it to the assigned Tailor, wait for stitching (normal delivery 3-4 days, or active Express Stitching 24 hours with premium rush fees), and deliver the finished, elegant dress back to their doorstep.

Keep the output aesthetic, professional, encouraging, and write in elegant English with clear Urdu/Hindustani phrases to give it a signature authentic boutique feel.
`;

  contents.push(prompt);

  // If a base64 image is uploaded, we convert it into a Gemini inlineData object
  if (image && typeof image === "string" && image.includes(";base64,")) {
    try {
      const parts = image.split(";base64,");
      const mimeType = parts[0].split(":")[1] || "image/jpeg";
      const base64Data = parts[1];
      
      contents.push({
        inlineData: {
          mimeType: mimeType,
          data: base64Data
        }
      });
      console.log(`Received base64 photo upload (${mimeType}). Forwarding to Gemini multimodal input!`);
    } catch (e) {
      console.error("Failed to parse base64 image data", e);
    }
  }

  if (!ai) {
    // Elegant fallback if API key is not ready
    return res.json({
      text: `### 🎨 Skin Tone & Aesthetic Analysis
Based on your selection of **${skinTone || "Warm Wheatish"}** undertone and **${ageGroup || "Young adult"}** age category, our boutique analysis suggests choosing rich jewel colors. For **${occasion || "Festive Events"}**, earthy maroons, deep emerald greens (Zamurrud), and rich navy blues will match beautifully. Avoid washed-out grays to maintain high color contrast.

### 🛍️ Wardrobe Recommendations (30 Pakistani Shops Matching)
- **Classic Pret Outfit (Stitched):** Standard cotton embroidered kurti/gents kameez from **Khaadi** or **J. (Junaid Jamshed)**. Estimate: Rs. 6,500. [Status: **In Stock**]
- **Formal Heavy Suit (Unstitched):** Rich raw silk or linen digital suit from **Sapphire** or **Maria B.** containing premium tilla patterns. Estimate: Rs. 12,000. [Status: **In Stock**]

### 🛵 Stitched: Instant Home Delivery Route
Since you selected **Stitched**, our integrated logistics panel suggests **Leopards Express Rider (Hassan Raza)**. Distance: 4.2 km. Scheduled handoff will happen within **3-4 hours** of order approval. Pay via Cash on Delivery (COD).

### 🪡 Unstitched: Tailor Studio and Pick & Drop Logistics
Since you chose **Unstitched fabric**, we recommend pairing this with **Master Ashfaq (Lahore Studio)** or **Master Siddique (Karachi)**. Once checked out, a local delivery rider will arrive on a bike to securely pick up your raw unstitched fabric along with a physical "fitting kameez" from your home. Sizing will be laser-scanned, stitched professionally within **3 days**, and returned right back to your door! (Urgent 24h stitching option available for Rs. 1,500 additional).

---
*💡 System Note: Proprietary Custom Neural Draping Model is active. Skin-tone values and ambient lights mapped to local brand inventory.*`
    });
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: contents,
      config: {
        systemInstruction: `You are the chief "AI Fashion Guru, Couture Consultant & Logistics System Director" for the Pakistan AI Fashion Hub. 
        You specialize in both Ladies and Gents Pakistani outfits. 
        You are highly expert in traditional Pakistani wear (Sherwanis, Kurta-Shalwar, Prince Coats, Lehenga, Saree, Shalwar Kameez) and contemporary styles.
        Always support the user's workflow: Image analysis -> Color/Age recommendation -> 30 Brands inventory check (Stitched / Unstitched) -> TCS / Leopards rider dispatch suggestions -> Local tailors network routing.
        Use gorgeous local terminology (ajrak, phulkari, jamawar, raw silk, lawn, cambric, chiffons, tilla, gota) with maximum professionalism.`
      }
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini API call failed:", error);
    res.status(500).json({ error: "Sorry, styling advisor is currently updating. Please try again soon.", details: error.message });
  }
});

// Serve static build or mount Vite in dev mode
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server starting on port ${PORT}...`);
    console.log(`Pakistan Fashion Platform dev environment ready on http://localhost:${PORT}`);
  });
}

startServer();
